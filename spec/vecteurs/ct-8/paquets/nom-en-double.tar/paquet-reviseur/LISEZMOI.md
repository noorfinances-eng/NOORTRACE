Seconde version des instructions, glissée après la construction.
